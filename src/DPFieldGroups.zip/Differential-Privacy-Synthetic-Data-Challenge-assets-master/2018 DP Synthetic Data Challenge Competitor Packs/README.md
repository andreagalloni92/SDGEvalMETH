<h1>2018 Differential Privacy Synthetic Data Challenge Alogorithms and Competitor Packs</h1>

These files pertain to the the NIST, PSCR 2018 (https://www.nist.gov/ctl/pscr/funding-opportunities/prizes-challenges/2018-differential-privacy-synthetic-data-challenge) including the final sprint algorithms (from competitors who elected to shared them). The 'Competitor Packs' provided to particpans for each sprint are also available here.

<h2>Differential Privacy Synthetic Data Challenge Competitor Packs</h2>

Each Competitor's Pack include the materials provided to partipants for each algorithm sprints. These packs include: challenge datasets, naive implemention of differentially private algorithm, scripts to run scoring method, scripts to prepare submissions to the implementor platform, and documentation.  

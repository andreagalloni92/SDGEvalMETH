=======
Credits
=======

Development Lead
----------------

* Haoyue Ping <hp1326@nyu.edu>
* Ke Yang <ky630@nyu.edu>

.. Contributors
.. ------------

.. None yet. Why not be the first?

import pandas as pd

class CusQuery(object):
   def __init__(self, data):
      self.data = data

   def run_query(self):
      pass

   def query1(self):

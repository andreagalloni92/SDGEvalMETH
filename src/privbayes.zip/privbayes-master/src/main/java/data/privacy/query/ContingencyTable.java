package data.privacy.query;

import java.util.HashMap;

public interface ContingencyTable {
	public HashMap<String, Double> getTable();
}
